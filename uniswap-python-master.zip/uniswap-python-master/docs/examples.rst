Examples
========

No examples here yet! Why don't you contribute some?

In the meantime, see the :ref:`Getting started` guide.
